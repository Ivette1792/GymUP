<!-- footer styles -->

<style>.u-footer .u-sheet-1 {
  min-height: 120px;
}
.u-footer .u-menu-1 {
  margin: 24px 0 0 auto;
}
.u-footer .u-nav-2 {
  font-size: 1.25rem;
}
.u-footer .u-image-1 {
  width: 0;
  height: 0;
  margin: 0 auto 60px 0;
}
.u-footer .u-logo-image-1 {
  width: 100%;
  height: 100%;
}</style>
